<?php

function runtime_prettier($movie_length)
{
    $hours = floor($movie_length/60);
    $minutes = $movie_length%60;
    if($minutes != 1)
    return "{$hours} hours and {$minutes} minutes";
    else
    return "{$hours} hours and {$minutes} minute";
}
