
<div class="footer"><?php echo Logo ?>.Copyright, toate drepturile rezervate <?php echo date("Y") ?>.</div>